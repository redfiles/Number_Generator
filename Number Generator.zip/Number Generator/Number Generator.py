import requests
import random

print("Welcome to num validator tool...")
print("--------------------------------")
print("Select the number")
print("1. Phone number generator")
print("2. About")
print("")


def choice():
    choice1 = int(input(":- "))
    print("")
    return choice1

def again():
    print("Welcome to num validator tool...")
    print("--------------------------------")
    print("Select the number")
    print("1. Phone number generator")
    print("2. About")
    print("")
    x = choice()
    
x = choice()

if(x == 1):
    print("Generate phone numbers. But, you must input country code.")
    cc = input("Country Code (Eg: +1): ")
    n = int(input("Quantity of numbers: "))
    def random_phone_num_generator():
        first = str(random.randint(100, 999))
        second = str(random.randint(1, 888)).zfill(3)
        last = (str(random.randint(1, 9998)).zfill(4))
        while last in ['1111', '2222', '3333', '4444', '5555', '6666', '7777', '8888']:
            last = (str(random.randint(1, 9998)).zfill(4))
        return '{}{}{}'.format(first, second, last)
    file = open("phone_numbers.txt","a")
    for i in range(0, n):
        numbers = cc + str(random_phone_num_generator()) + "\n"
        file.write(numbers)
    file.close()
    
elif(x == 2):
    print("About")
    print("------------------------")
    print("Tool Name : Number Generator")
    print("Tool Purpose : You can generate phone numbers")
    print("Telegram Channel: https://t.me/black_money_2022")
    print("Telegram Username: @dom_black_hat")
    print("------------------------")
    print("99. Back to home")
    ome = int(input(":- "))
    if(ome == 99):
        print("------------------------")
        again()
    else:
        print("Wrong number!")
else:
    print("Wrong choice... Try again")
    print("")
    choice()




